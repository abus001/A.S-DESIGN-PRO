# A.S DESIGN PRO — Digital Payments

A mobile-first wallet and digital-services app with a black, gold and white interface. The official A.S DESIGN PRO crown-and-lion logo is included as `logo.png`.

## Project files
- `index.html`, `style.css`, `app.js` — frontend (kept together in one folder)
- `server.js` — Node.js/Express API server
- `package.json` — dependencies and start scripts
- `.env.example` — environment-variable template; copy it to `.env` on your server
- `logo.png` — supplied A.S DESIGN PRO logo

## Run locally
Requires Node.js 20 or newer. Open a terminal in this folder and run:

```bash
cp .env.example .env
npm install
npm start
```

Then open `http://localhost:3000`. Set a strong random `JWT_SECRET` and add valid provider credentials to `.env` before testing payments. Never upload `.env` or real API secrets to GitHub.

## Provider setup
1. Create/approve your Monnify merchant account and add the API key, secret key, contract code and redirect URL. Configure webhook URL as `https://YOUR-DOMAIN/api/webhooks/monnify`.
2. Add your VTpass API key and secret. Confirm your account's correct sandbox/production base URL and service variation codes.
3. Keep the app in sandbox while testing. Switch to live endpoints only after provider approval and end-to-end tests.

## Included modules
Dashboard, account registration/sign-in, wallet display, transaction history, Monnify checkout funding, Monnify reserved virtual account request, referral display, and service forms for data, airtime, cable, electricity and education. Bulk SMS, recharge PIN and airtime swap are shown as modules but require their own provider integrations.

## Important production checklist
This is an integration starter, not a certified or production-audited financial platform. Before accepting public customer funds, have the backend reviewed and complete: provider-specific service mapping and status polling, robust webhook signature/idempotency and amount/currency checks, refund/reconciliation workflows, account verification/KYC, rate/fee rules, admin controls, audit logs, backups, HTTPS, abuse monitoring and legal/compliance requirements. Do not use a real customer's BVN until the merchant/provider flow and data-protection controls are approved.

The frontend uses same-origin `/api` routes by default. For a separate API host, set `window.AS_DESIGN_PRO_API_BASE` before loading `app.js` and update the backend CORS allowlist.
